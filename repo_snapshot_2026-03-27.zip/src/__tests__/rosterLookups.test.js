import { buildRosterLookups } from '../components/windows';

// ── buildRosterLookups ────────────────────────────────────────
// Converts identityRegistry (pseudonym-keyed) into stable studentId-keyed
// lookup maps so RosterPanel display never touches s.pseudonym as a key.
describe('buildRosterLookups', () => {
  const allStudents = {
    'stu_1': { id: 'stu_1', pseudonym: 'Red Student 1',  color: '#ef4444', imported: true },
    'stu_2': { id: 'stu_2', pseudonym: 'Blue Student 1', color: '#3b82f6', imported: true },
    'stu_3': { id: 'stu_3', pseudonym: 'Green Student 1',color: '#22c55e', imported: false },
  };
  const identityRegistry = [
    { realName: 'Alice Smith',  pseudonym: 'Red Student 1',  color: '#ef4444', periodIds: ['p1'], classLabels: {} },
    { realName: 'Bob Jones',    pseudonym: 'Blue Student 1', color: '#3b82f6', periodIds: ['p1', 'p2'], classLabels: {} },
  ];

  test('nameById is keyed by studentId, not pseudonym', () => {
    const { nameById } = buildRosterLookups(allStudents, identityRegistry);
    expect(nameById['stu_1']).toBe('Alice Smith');
    expect(nameById['stu_2']).toBe('Bob Jones');
  });

  test('periodIdsById is keyed by studentId', () => {
    const { periodIdsById } = buildRosterLookups(allStudents, identityRegistry);
    expect(periodIdsById['stu_1']).toEqual(['p1']);
    expect(periodIdsById['stu_2']).toEqual(['p1', 'p2']);
  });

  test('students not in identityRegistry get no entry', () => {
    const { nameById, periodIdsById } = buildRosterLookups(allStudents, identityRegistry);
    expect(nameById['stu_3']).toBeUndefined();
    expect(periodIdsById['stu_3']).toBeUndefined();
  });

  test('registry entry with no matching student is skipped safely', () => {
    const registry = [
      { realName: 'Ghost Person', pseudonym: 'Purple Student 9', periodIds: [] },
    ];
    const { nameById, periodIdsById } = buildRosterLookups(allStudents, registry);
    expect(Object.keys(nameById)).toHaveLength(0);
    expect(Object.keys(periodIdsById)).toHaveLength(0);
  });

  test('empty allStudents returns empty maps', () => {
    const { nameById, periodIdsById } = buildRosterLookups({}, identityRegistry);
    expect(nameById).toEqual({});
    expect(periodIdsById).toEqual({});
  });

  test('empty identityRegistry returns empty maps', () => {
    const { nameById, periodIdsById } = buildRosterLookups(allStudents, []);
    expect(nameById).toEqual({});
    expect(periodIdsById).toEqual({});
  });

  test('non-imported student with matching pseudonym still gets a lookup entry', () => {
    // stu_3 is not imported but has a pseudonym — should still be resolvable
    const registry = [
      { realName: 'Carol Lee', pseudonym: 'Green Student 1', periodIds: ['p3'] },
    ];
    const { nameById } = buildRosterLookups(allStudents, registry);
    expect(nameById['stu_3']).toBe('Carol Lee');
  });
});
